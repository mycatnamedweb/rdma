#!/bin/bash

./autogen.sh && ./configure && make clean && make
