#!/bin/bash

echo "Starting client and connecting to running server.."

./ib_send_lat -d mlx5_0 -U --size=100 192.18.200.4
