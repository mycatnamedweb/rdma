#!/bin/bash

echo "Starting server.."

./ib_send_lat -d mlx5_0 -U --size=100
